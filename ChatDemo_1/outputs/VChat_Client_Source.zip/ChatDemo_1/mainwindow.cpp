﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QListWidgetItem>

MainWindow::MainWindow(const QString &loginName, const QString &serverAddress, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , nickname(loginName.trimmed().isEmpty() ? QStringLiteral("User") : loginName.trimmed())
    , isConnected(false)
    , socket(new QTcpSocket(this))
{
    ui->setupUi(this);

    // 主窗口创建后，先设置界面，再连接网络信号，最后根据登录界面的服务器地址自动连接。
    setupUI();
    connectSlots();
    updateUserList();

    appendSystemMessage("欢迎使用 VChat");
    appendSystemMessage("当前昵称: " + nickname);

    if (serverAddress.trimmed().isEmpty()) {
        appendSystemMessage("请选择 文件 -> 连接服务器 开始聊天");
    } else {
        connectToServerAddress(serverAddress, false);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupUI()
{
    setWindowTitle("VChat - " + nickname);

    // 聊天记录区域使用 QTextBrowser，可以显示带颜色和气泡效果的 HTML 文本。
    ui->chatDisplay->setStyleSheet(
        "QTextBrowser {"
        "    background-color: #f5f5f5;"
        "    color: #333333;"
        "    border: 1px solid #ddd;"
        "    border-radius: 8px;"
        "    padding: 10px;"
        "    font-size: 14px;"
        "}"
    );

    // 输入框单独设置文字颜色，避免深色主题下输入中文时看不清。
    ui->messageInput->setStyleSheet(
        "QLineEdit {"
        "    border: 2px solid #ddd;"
        "    border-radius: 20px;"
        "    padding: 8px 15px;"
        "    font-size: 14px;"
        "    background-color: white;"
        "    color: #111827;"
        "    selection-color: white;"
        "    selection-background-color: #4CAF50;"
        "}"
        "QLineEdit:focus {"
        "    border-color: #4CAF50;"
        "}"
        "QLineEdit:disabled {"
        "    color: #6b7280;"
        "    background-color: #f3f4f6;"
        "}"
    );

    // QPalette 是 Qt 控件本身的调色板，和 QSS 配合使用可以更稳定地控制文字颜色。
    QPalette inputPalette = ui->messageInput->palette();
    inputPalette.setColor(QPalette::Text, QColor("#111827"));
    inputPalette.setColor(QPalette::PlaceholderText, QColor("#9ca3af"));
    inputPalette.setColor(QPalette::Base, QColor("#ffffff"));
    ui->messageInput->setPalette(inputPalette);

    // 发送按钮样式。
    ui->sendButton->setStyleSheet(
        "QPushButton {"
        "    background-color: #4CAF50;"
        "    color: white;"
        "    border: none;"
        "    border-radius: 20px;"
        "    padding: 8px 20px;"
        "    font-size: 14px;"
        "    font-weight: bold;"
        "}"
        "QPushButton:hover { background-color: #45a049; }"
        "QPushButton:pressed { background-color: #3d8b40; }"
    );

    // 在线用户列表样式。
    ui->userList->setStyleSheet(
        "QListWidget {"
        "    background-color: white;"
        "    color: #333333;"
        "    border: 1px solid #ddd;"
        "    border-radius: 8px;"
        "    padding: 5px;"
        "    font-size: 13px;"
        "}"
        "QListWidget::item {"
        "    padding: 8px;"
        "    border-radius: 4px;"
        "    margin: 2px 0;"
        "}"
        "QListWidget::item:selected {"
        "    background-color: #e3f2ed;"
        "    color: #1976d2;"
        "}"
        "QListWidget::item:hover { background-color: #f5f5f5; }"
    );

    ui->serverStatusLabel->setText("服务器状态: 未连接");
    ui->serverStatusLabel->setStyleSheet("color: #f44336;");
    statusBar()->showMessage("就绪");
}

void MainWindow::connectSlots()
{
    // .ui 中的 on_xxx_signal 槽函数由 setupUi 自动连接，这里只连接网络 socket。
    // 连接成功后，客户端会立刻发送 JOIN|昵称，让服务器知道这个用户正式进入聊天界面。
    connect(socket, &QTcpSocket::connected, this, [this]() {
        isConnected = true;
        ui->serverStatusLabel->setText("服务器状态: 已连接");
        ui->serverStatusLabel->setStyleSheet("color: #4CAF50;");
        appendSystemMessage("已连接到聊天服务器");
        statusBar()->showMessage("已连接到聊天服务器");
        sendJoinMessage();
    });

    // 断开连接后，界面状态恢复为“未连接”，在线列表也只显示自己。
    connect(socket, &QTcpSocket::disconnected, this, [this]() {
        isConnected = false;
        ui->serverStatusLabel->setText("服务器状态: 未连接");
        ui->serverStatusLabel->setStyleSheet("color: #f44336;");
        updateUserList();
        appendSystemMessage("已断开与聊天服务器的连接");
        statusBar()->showMessage("已断开连接");
    });

    // readyRead 表示服务器有新数据发过来了，读取工作交给 on_socketReadyRead()。
    connect(socket, &QTcpSocket::readyRead, this, &MainWindow::on_socketReadyRead);

    // 连接失败、服务器关闭等网络错误都会进入这里。
    connect(socket, &QTcpSocket::errorOccurred, this, [this](QAbstractSocket::SocketError) {
        isConnected = false;
        ui->serverStatusLabel->setText("服务器状态: 未连接");
        ui->serverStatusLabel->setStyleSheet("color: #f44336;");
        appendSystemMessage("连接服务器失败: " + socket->errorString());
        statusBar()->showMessage("连接服务器失败");
    });
}

void MainWindow::on_sendButton_clicked()
{
    const QString message = ui->messageInput->text().trimmed();
    if (message.isEmpty()) {
        return;
    }

    if (!isConnected || socket->state() != QAbstractSocket::ConnectedState) {
        appendSystemMessage("请先连接服务器");
        return;
    }

    // 本项目使用最简单的文本协议：每条消息以换行符 \n 结束。
    // 服务器收到 “昵称: 内容” 后，会转发给其他在线客户端，并保存到数据库。
    const QString networkMessage = nickname + ": " + message + "\n";
    if (socket->write(networkMessage.toUtf8()) == -1) {
        appendSystemMessage("消息发送失败: " + socket->errorString());
        return;
    }

    appendMessage(nickname, message);
    ui->messageInput->clear();
    ui->messageInput->setFocus();
}

void MainWindow::on_messageInput_returnPressed()
{
    on_sendButton_clicked();
}

void MainWindow::on_socketReadyRead()
{
    // TCP 是流式传输，不能保证一次 readyRead 正好是一条完整消息。
    // 所以先追加到 receiveBuffer，再按 \n 一行一行拆出来处理。
    receiveBuffer.append(socket->readAll());

    int lineEnd = -1;
    while ((lineEnd = receiveBuffer.indexOf('\n')) != -1) {
        const QByteArray lineBytes = receiveBuffer.left(lineEnd).trimmed();
        receiveBuffer.remove(0, lineEnd + 1);

        if (!lineBytes.isEmpty()) {
            appendIncomingLine(QString::fromUtf8(lineBytes));
        }
    }
}

void MainWindow::on_actionConnect_triggered()
{
    // 菜单栏“连接服务器”会弹出输入框，手动填写服务器 IP 和端口。
    bool ok = false;
    const QString serverAddress = QInputDialog::getText(
        this,
        "连接服务器",
        "请输入服务器地址:",
        QLineEdit::Normal,
        "127.0.0.1:8080",
        &ok);

    if (ok && !serverAddress.trimmed().isEmpty()) {
        connectToServerAddress(serverAddress, true);
    }
}

void MainWindow::on_actionDisconnect_triggered()
{
    if (socket->state() == QAbstractSocket::UnconnectedState) {
        appendSystemMessage("当前没有连接服务器");
        return;
    }

    appendSystemMessage("正在断开服务器连接...");
    socket->disconnectFromHost();
}

void MainWindow::on_actionExit_triggered()
{
    close();
}

void MainWindow::on_actionChangeNickname_triggered()
{
    bool ok = false;
    const QString newNickname = QInputDialog::getText(
        this,
        "修改昵称",
        "请输入新昵称:",
        QLineEdit::Normal,
        nickname,
        &ok);

    if (!ok || newNickname.trimmed().isEmpty()) {
        return;
    }

    const QString oldNickname = nickname;
    nickname = newNickname.trimmed();
    setWindowTitle("VChat - " + nickname);
    appendSystemMessage(oldNickname + " 修改昵称为 " + nickname);

    // 如果已经连接服务器，改名后重新发送 JOIN，让服务器刷新在线列表里的名字。
    if (socket->state() == QAbstractSocket::ConnectedState) {
        sendJoinMessage();
    }
}

void MainWindow::on_actionAbout_triggered()
{
    QMessageBox::about(
        this,
        "关于 VChat",
        "VChat 学生群体聊天系统\n\n"
        "基于 Qt6 开发，支持登录验证、局域网聊天、服务器转发、在线用户列表和聊天记录保存。"
    );
}

bool MainWindow::connectToServerAddress(const QString &address, bool showErrorMessage)
{
    const QString serverAddress = address.trimmed();

    // 服务器地址约定为 “IP:端口”，例如 192.168.1.10:8080。
    // lastIndexOf(':') 可以兼容 IP 中没有冒号的普通 IPv4 地址。
    const int separatorIndex = serverAddress.lastIndexOf(':');
    if (separatorIndex <= 0 || separatorIndex == serverAddress.size() - 1) {
        if (showErrorMessage) {
            QMessageBox::warning(this, "连接失败", "服务器地址格式应为 IP:端口，例如 127.0.0.1:8080");
        } else {
            appendSystemMessage("服务器地址格式不正确: " + serverAddress);
        }
        return false;
    }

    const QString host = serverAddress.left(separatorIndex).trimmed();
    bool portOk = false;
    const quint16 port = serverAddress.mid(separatorIndex + 1).trimmed().toUShort(&portOk);
    if (!portOk || port == 0) {
        if (showErrorMessage) {
            QMessageBox::warning(this, "连接失败", "端口号不正确，例如 8080");
        } else {
            appendSystemMessage("服务器端口不正确: " + serverAddress);
        }
        return false;
    }

    // 如果之前连过其他服务器，先 abort 关闭旧连接，再连接新地址。
    if (socket->state() != QAbstractSocket::UnconnectedState) {
        socket->abort();
    }

    appendSystemMessage("正在连接服务器: " + host + ":" + QString::number(port));
    statusBar()->showMessage("正在连接服务器...");
    socket->connectToHost(host, port);
    return true;
}

void MainWindow::sendJoinMessage()
{
    if (socket->state() == QAbstractSocket::ConnectedState) {
        // JOIN 协议只负责“上线通知”，不保存到聊天记录表。
        socket->write(("JOIN|" + nickname + "\n").toUtf8());
    }
}

void MainWindow::appendMessage(const QString &user, const QString &message)
{
    const QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss");

    // 聊天内容来自用户输入或网络，转成 HTML 前要转义，避免特殊字符破坏界面格式。
    const QString safeUser = user.toHtmlEscaped();
    const QString safeMessage = message.toHtmlEscaped();

    QString html;
    if (user == nickname) {
        // 自己发的消息靠右显示，方便和别人发来的消息区分。
        html = QString(
            "<div style='margin: 10px 0; text-align: right;'>"
            "<span style='color: #666; font-size: 12px;'>%1 </span>"
            "<span style='color: #4CAF50; font-weight: bold;'>%2</span><br>"
            "<span style='background-color: #e8f5e9; padding: 8px 12px; border-radius: 15px; display: inline-block; margin-top: 5px;'>%3</span>"
            "</div>"
        ).arg(timestamp, safeUser, safeMessage);
    } else {
        // 其他人的消息靠左显示。
        html = QString(
            "<div style='margin: 10px 0; text-align: left;'>"
            "<span style='color: #2196F3; font-weight: bold;'>%2</span>"
            "<span style='color: #666; font-size: 12px;'> %1</span><br>"
            "<span style='background-color: #e3f2fd; padding: 8px 12px; border-radius: 15px; display: inline-block; margin-top: 5px;'>%3</span>"
            "</div>"
        ).arg(timestamp, safeUser, safeMessage);
    }

    ui->chatDisplay->append(html);
    ui->chatDisplay->verticalScrollBar()->setValue(ui->chatDisplay->verticalScrollBar()->maximum());
}

void MainWindow::appendSystemMessage(const QString &message)
{
    const QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss");
    const QString safeMessage = message.toHtmlEscaped();
    const QString html = QString(
        "<div style='margin: 10px 0; text-align: center;'>"
        "<span style='color: #999; font-size: 12px; background-color: #f0f0f0; padding: 4px 12px; border-radius: 10px;'>"
        "%1 %2"
        "</span>"
        "</div>"
    ).arg(timestamp, safeMessage);

    ui->chatDisplay->append(html);
    ui->chatDisplay->verticalScrollBar()->setValue(ui->chatDisplay->verticalScrollBar()->maximum());
}

void MainWindow::appendIncomingLine(const QString &line)
{
    // 服务器发来的在线用户列表格式：USERLIST|张三,李四
    if (line.startsWith("USERLIST|")) {
        QStringList users = line.mid(QStringLiteral("USERLIST|").size()).split(',', Qt::SkipEmptyParts);
        for (QString &user : users) {
            user = user.trimmed();
        }
        updateUserList(users);
        return;
    }

    // 服务器系统提示以 [System] 开头，例如用户加入、用户离开。
    if (line.startsWith("[System]")) {
        appendSystemMessage(line);
        return;
    }

    // 其余内容都当作普通聊天消息显示。
    appendMessage("服务器转发", line);
}

void MainWindow::updateUserList(const QStringList &users)
{
    // 没有连上服务器时，右侧列表至少显示当前用户自己。
    const QStringList displayUsers = users.isEmpty() ? (QStringList() << nickname) : users;

    ui->userList->clear();
    for (const QString &user : displayUsers) {
        const QString displayName = (user == nickname) ? user + " (我)" : user;
        QListWidgetItem *item = new QListWidgetItem(displayName);
        if (user == nickname) {
            item->setForeground(QColor("#4CAF50"));
        }
        ui->userList->addItem(item);
    }

    ui->onlineCountLabel->setText("在线人数: " + QString::number(displayUsers.size()));
}
