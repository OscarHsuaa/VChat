﻿#include "logindialog.h"
#include "ui_logindialog.h"

#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QRandomGenerator>
#include <QTcpSocket>

LoginDialog::LoginDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::LoginDialog)
    , serverEdit(new QLineEdit(this))
{
    ui->setupUi(this);

    // 登录时需要先连接 ChatServer，服务器再去查询 vchat_demo.users 表。
    // 默认填写本机地址，自己电脑同时运行客户端和服务器时可以直接使用。
    serverEdit->setText(QStringLiteral("127.0.0.1:8080"));
    serverEdit->setPlaceholderText(QStringLiteral("例如 127.0.0.1:8080"));
    ui->formLayout->insertRow(0, QStringLiteral("服务器:"), serverEdit);

    // 登录界面标题改成项目名称，隐藏原来的测试账号提示。
    ui->titleLabel->setText(QStringLiteral("VChat"));
    ui->hintLabel->hide();

    refreshCaptcha();

    // 绑定登录界面的按钮事件。
    connect(ui->refreshCaptchaButton, &QPushButton::clicked, this, &LoginDialog::refreshCaptcha);
    connect(ui->loginButton, &QPushButton::clicked, this, &LoginDialog::tryLogin);
    connect(ui->cancelButton, &QPushButton::clicked, this, &LoginDialog::reject);
    connect(ui->passwordEdit, &QLineEdit::returnPressed, this, &LoginDialog::tryLogin);
    connect(ui->captchaEdit, &QLineEdit::returnPressed, this, &LoginDialog::tryLogin);
}

QString LoginDialog::username() const
{
    // 登录成功后优先返回数据库里的昵称，例如 张三、李四。
    // 如果服务器没有返回昵称，则退回到用户输入的账号。
    return loggedInNickname.isEmpty() ? ui->usernameEdit->text().trimmed() : loggedInNickname;
}

QString LoginDialog::serverAddress() const
{
    return serverEdit->text().trimmed();
}

void LoginDialog::refreshCaptcha()
{
    // 每次刷新或输入错误后，重新生成验证码并清空输入框。
    captchaCode = createCaptcha();
    ui->captchaCodeLabel->setText(captchaCode);
    ui->captchaEdit->clear();
}

void LoginDialog::tryLogin()
{
    // 1. 读取用户输入。
    const QString name = ui->usernameEdit->text().trimmed();
    const QString password = ui->passwordEdit->text();
    const QString inputCaptcha = ui->captchaEdit->text().trimmed();

    // 2. 先做本地基本检查，账号密码不能为空。
    if (name.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("登录失败"), QStringLiteral("请输入账号和密码。"));
        return;
    }

    // 3. 验证码仍然在客户端本地判断，账号密码交给 ChatServer 查询 users 表。
    // compare 使用 CaseInsensitive，所以验证码不区分大小写。
    if (inputCaptcha.compare(captchaCode, Qt::CaseInsensitive) != 0) {
        QMessageBox::warning(this, QStringLiteral("登录失败"), QStringLiteral("验证码错误，请重新输入。"));
        refreshCaptcha();
        ui->captchaEdit->setFocus();
        return;
    }

    // 4. 验证码通过后，再连接服务器验证数据库 users 表里的账号密码。
    QString errorMessage;
    if (!authenticateWithServer(name, password, &errorMessage)) {
        QMessageBox::warning(this, QStringLiteral("登录失败"), errorMessage);
        refreshCaptcha();
        ui->passwordEdit->clear();
        ui->passwordEdit->setFocus();
        return;
    }

    // 5. 全部验证成功，关闭登录窗口并进入主聊天窗口。
    accept();
}

QString LoginDialog::createCaptcha() const
{
    // 去掉了容易混淆的字符，例如 I、O、0、1，避免用户看错。
    static const QString chars = QStringLiteral("ABCDEFGHJKLMNPQRSTUVWXYZ23456789");
    QString code;
    code.reserve(5);

    for (int i = 0; i < 5; ++i) {
        const int index = QRandomGenerator::global()->bounded(chars.size());
        code.append(chars.at(index));
    }

    return code;
}

bool LoginDialog::authenticateWithServer(const QString &username, const QString &password, QString *errorMessage)
{
    const QString address = serverEdit->text().trimmed();

    // 服务器地址格式约定为 “IP:端口”，例如 192.168.1.20:8080。
    const int separatorIndex = address.lastIndexOf(':');
    if (separatorIndex <= 0 || separatorIndex == address.size() - 1) {
        *errorMessage = QStringLiteral("服务器地址格式应为 IP:端口，例如 127.0.0.1:8080。");
        return false;
    }

    const QString host = address.left(separatorIndex).trimmed();
    bool portOk = false;
    const quint16 port = address.mid(separatorIndex + 1).trimmed().toUShort(&portOk);
    if (!portOk || port == 0) {
        *errorMessage = QStringLiteral("服务器端口不正确。");
        return false;
    }

    QTcpSocket socket;

    // 登录阶段使用一个临时 socket，只负责账号验证。
    // 验证成功进入主窗口后，主窗口会再建立正式聊天连接。
    socket.connectToHost(host, port);
    if (!socket.waitForConnected(3000)) {
        *errorMessage = QStringLiteral("连接登录服务器失败：") + socket.errorString();
        return false;
    }

    // 简单登录协议：LOGIN|username|password\n
    // ChatServer 收到后查询 vchat_demo.users 表。
    const QString request = QStringLiteral("LOGIN|%1|%2\n").arg(username, password);
    socket.write(request.toUtf8());
    if (!socket.waitForBytesWritten(3000)) {
        *errorMessage = QStringLiteral("发送登录请求失败：") + socket.errorString();
        return false;
    }

    // 服务器连接成功时可能先返回 [System] 提示，所以这里循环读取，直到读到 LOGIN_OK 或 LOGIN_FAIL。
    // LOGIN_OK 后面带的是昵称，例如 LOGIN_OK|张三。
    QString lastResponse;
    while (socket.waitForReadyRead(3000)) {
        while (socket.canReadLine()) {
            const QString response = QString::fromUtf8(socket.readLine().trimmed());
            lastResponse = response;

            if (response.startsWith(QStringLiteral("LOGIN_OK|"))) {
                loggedInNickname = response.mid(QStringLiteral("LOGIN_OK|").size()).trimmed();
                if (loggedInNickname.isEmpty()) {
                    loggedInNickname = username;
                }
                return true;
            }

            if (response.startsWith(QStringLiteral("LOGIN_FAIL|"))) {
                *errorMessage = response.mid(QStringLiteral("LOGIN_FAIL|").size()).trimmed();
                if (errorMessage->isEmpty()) {
                    *errorMessage = QStringLiteral("账号或密码错误。");
                }
                return false;
            }
        }
    }

    if (lastResponse.isEmpty()) {
        *errorMessage = QStringLiteral("服务器没有返回登录结果。");
        return false;
    }

    *errorMessage = QStringLiteral("服务器返回了无法识别的登录结果：") + lastResponse;
    return false;
}

